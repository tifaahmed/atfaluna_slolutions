import Model    from './Model';
import   RouterPermission    from './Routers/Permission' ;

export default class Permission  extends Model {



}