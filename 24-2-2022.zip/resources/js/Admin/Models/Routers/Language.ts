
import   RouterRouter    from './Router' ;

export default class Language extends RouterRouter{
    name : string = 'language' ;

}