
import   RouterRouter    from './Router' ;

export default class Subscription extends RouterRouter{
    name : string = 'age-group' ;

}