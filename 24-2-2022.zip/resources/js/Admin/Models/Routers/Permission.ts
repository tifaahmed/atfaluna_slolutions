
// import Router        from './Router'    ;

import Axios from 'axios' ;
import jwt   from './../../../Services/jwt' ;
import   RouterRouter    from './Router' ;

export default class Permission extends RouterRouter{
    name : string = 'Permission' ;

    

}