
import   RouterRouter    from './Router' ;

export default class Country extends RouterRouter{
    name : string = 'country' ;

}