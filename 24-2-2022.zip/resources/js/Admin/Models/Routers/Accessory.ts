
import   RouterRouter    from './Router' ;

export default class Accessory extends RouterRouter{
    name : string = 'accessory' ;

}