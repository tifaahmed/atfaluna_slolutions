<template>
	<div>
Welcome
o'jkojk

	</div>
</template>
<script>
    export default {
        mounted() {
            console.log( 'Welcome _page ' );
        },
    }
</script>
