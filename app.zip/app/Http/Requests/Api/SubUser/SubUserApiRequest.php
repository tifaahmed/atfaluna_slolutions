<?php

namespace App\Http\Requests\Api\SubUser;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SubUserApiRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'gender'=>[
                'required',
                    Rule::in(['boy', 'girl']),
            ],
            'name'       =>  [ 'required' ] ,
            'age'        =>  [ 'required' ,'integer','exists:ages,age'] ,
            'points'     =>  [ 'integer' ] ,
            'user_id'    =>  [ 'required','integer' ,'exists:users,id'] ,
            'avatar_ids' =>  [ 'sometimes','array','exists:avatars,id' ] ,
            'avatar_id'  =>  [ 'sometimes','integer','exists:avatars,id' ] ,

        ];
    }
}
