<?php

namespace App\Repository;

interface AchievementRepositoryInterface extends EloquentRepositoryInterface{
}
