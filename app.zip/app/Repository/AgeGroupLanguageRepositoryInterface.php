<?php

namespace App\Repository;

interface AgeGroupLanguageRepositoryInterface extends EloquentRepositoryInterface{

}
