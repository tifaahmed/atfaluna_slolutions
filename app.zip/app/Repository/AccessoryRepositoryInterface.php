<?php

namespace App\Repository;

interface AccessoryRepositoryInterface extends EloquentRepositoryInterface{

}
