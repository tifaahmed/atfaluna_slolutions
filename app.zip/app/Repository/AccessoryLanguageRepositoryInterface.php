<?php

namespace App\Repository;

interface AccessoryLanguageRepositoryInterface extends EloquentRepositoryInterface{

}
