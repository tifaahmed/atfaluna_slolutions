<?php

namespace App\Repository;

interface AgeRepositoryInterface extends EloquentRepositoryInterface{

}
