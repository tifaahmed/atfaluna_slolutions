<?php

namespace App\Http\Resources\Dashboard\Skill;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Dashboard\Collections\Lesson\LessonCollection;

use App\Http\Resources\Dashboard\Collections\Skill\SkillLanguagesCollection;

class SkillResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
    $row=$this->skill_languages()->Localization()->RelatedLanguage($this->id)->first();

        return [
            'id'            => $this->id,

            'name'          => $row ? $row->name:'',
            // 'languages'     => $this->skill_languages,

            'languages'     => new SkillLanguagesCollection ( $this->skill_languages ),
            'created_at'    => $this->created_at ?   $this->created_at->format('d/m/Y') : null,
            'updated_at'    => $this->updated_at ?   $this->updated_at->format('d/m/Y') : null,
            'deleted_at'    => $this->deleted_at ?   $this->deleted_at->format('d/m/Y') : null,

            // 'lessons'        => new LessonCollection ($this->herolesson)  ,

        ];        
    }
}
//