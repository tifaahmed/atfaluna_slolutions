<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class QuizQuestionsController extends Controller
{
    //
}
