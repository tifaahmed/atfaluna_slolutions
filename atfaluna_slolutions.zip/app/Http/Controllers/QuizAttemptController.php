<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class QuizAttemptController extends Controller
{
    //
}
